let cart = [];
let total = 0;

function addToCart(item, price) {
    // Check if the item is already in the cart
    const existingItem = cart.find(cartItem => cartItem.item === item);
    if (existingItem) {
        // If the item is already in the cart, increase the quantity
        existingItem.quantity += 1;
        existingItem.price += price; // Update the total price for the item
    } else {
        // If the item is not in the cart, add it
        cart.push({ item, price, quantity: 1 });
    }
    total += price; // Update the total price
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = ''; // Clear the current cart items
    cart.forEach(cartItem => {
        const li = document.createElement('li');
        li.textContent = `${cartItem.item} - ₹${cartItem.price} (x${cartItem.quantity})`;
        cartItems.appendChild(li);
    });
    document.getElementById('total-price').textContent = `Total: ₹${total}`;
}

function checkout() {
    if (cart.length === 0) {
        alert("Your cart is empty!");
    } else {
        alert("Thank you for your order!");
        cart = []; // Clear the cart
        total = 0; // Reset total
        updateCart(); // Update the cart display
    }
}